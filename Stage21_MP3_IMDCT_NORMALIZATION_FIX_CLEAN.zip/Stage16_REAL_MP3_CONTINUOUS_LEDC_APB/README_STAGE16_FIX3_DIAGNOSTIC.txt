Stage16-FIX3
REAL MP3 CONTINUOUS PLAYBACK + PCM PROGRESS DIAGNOSTICS

This version is based directly on Stage16-FIX2.
No test sine and no repeated test PCM were added.

Additional USBSerial diagnostics:
- decoded/skipped frame count
- total REAL PCM samples queued
- decoded PCM duration
- ring-buffer queue depth
- PWM underrun count

MPEG-1 Layer III: 1152 PCM samples are counted for each successfully
decoded frame.

GPIO16 remains the PWM output.
LEDC carrier remains 312500 Hz, 8-bit, APB clock.


STAGE17 SYNTHESIS INTEGRATION
------------------------------
MP3Synthesis now contains an explicit 32-input/64-output synthesis DCT stage, persistent per-channel 1024-value FIFO, ISO 512-point D-window and 32-sample polyphase output. The existing decoder already calls mp3SynthesisProcess() for every decoded granule; the synthesis state is reset only once per file.
