#!/usr/bin/env python3
"""Convert the USBSerial PCM capture from Stage17 into a WAV file.

Usage:
    python make_wav.py serial_log.txt captured.wav
"""
import re
import sys
import wave

if len(sys.argv) != 3:
    print("Usage: python make_wav.py serial_log.txt captured.wav")
    raise SystemExit(2)

src, dst = sys.argv[1], sys.argv[2]
text = open(src, "r", encoding="utf-8", errors="replace").read()

m_rate = re.search(r"PCM_CAPTURE_RATE=(\d+)", text)
if not m_rate:
    raise SystemExit("PCM_CAPTURE_RATE not found")
rate = int(m_rate.group(1))

m_data = re.search(r"PCM_CAPTURE_DATA_BEGIN\s*\n(.*?)\nPCM_CAPTURE_DATA_END", text, re.S)
if not m_data:
    raise SystemExit("PCM_CAPTURE_DATA_BEGIN/END not found")

audio = bytearray()
count = 0
for line in m_data.group(1).splitlines():
    line = line.strip()
    if not re.fullmatch(r"-?\d+,-?\d+", line):
        continue
    l, r = (int(x) for x in line.split(','))
    l = max(-32768, min(32767, l))
    r = max(-32768, min(32767, r))
    audio += int(l).to_bytes(2, "little", signed=True)
    audio += int(r).to_bytes(2, "little", signed=True)
    count += 1

if not count:
    raise SystemExit("No PCM samples found")

with wave.open(dst, "wb") as w:
    w.setnchannels(2)
    w.setsampwidth(2)
    w.setframerate(rate)
    w.writeframes(audio)

print(f"Wrote {dst}: {count} stereo samples, {count/rate:.3f} seconds @ {rate} Hz")
