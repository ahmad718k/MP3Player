STAGE14-FIX3 DIAGNOSTIC

This version keeps USB/FAT/MP3 loading and GPIO16 PWM unchanged.

It adds diagnostics at four points:
1) Huffman spectral data
2) requantized XR
3) hybrid IMDCT
4) final PCM

PWM also reports PCM and duty statistics.

Run it with music.mp3 in the same internal FAT storage partition.
EJECT is not required.

GPIO16 = PWM output
PWM carrier = 312.5 kHz
Audio rate for the supplied file = 44100 Hz

The purpose is to identify the FIRST stage where the signal becomes zero.
