STAGE17 WAV TEST
================

Target: ESP32-S2, Arduino-ESP32 3.3.x, 4 MB flash.

Storage partition remains the existing raw FAT partition:
  storage, data, fat, 0x190000, 0x270000

USB MSC exposes the raw FAT partition exactly as before.
The device waits for Windows to EJECT the drive. Only after EJECT is the
FAT filesystem mounted read/write by a small raw-flash FatFs disk driver.
This avoids mounting the same FAT filesystem simultaneously through MSC
and FatFs.

The MP3 decoder then writes:
  /storage/test.wav

The file is always opened with "wb+", so every test replaces the previous
/test.wav instead of creating additional files.

WAV format:
  PCM
  16-bit signed little endian
  44.1 kHz (taken from the decoded MP3 frame)
  stereo when the MP3 has two channels
  maximum duration: 5 seconds

For this test PWM playback is disabled. The purpose is to inspect the
actual decoded PCM independently of PWM underruns.

After the WAV is finalized the filesystem is unmounted and the ESP32-S2
restarts. Windows can then enumerate the MSC drive again and test.wav can
be copied/opened directly.
